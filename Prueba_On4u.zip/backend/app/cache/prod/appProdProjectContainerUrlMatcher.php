<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/api/producto')) {
            // get_productos
            if (0 === strpos($pathinfo, '/api/productos') && preg_match('#^/api/productos(?:\\.(?P<_format>xml|json|html))?$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_get_productos;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_productos')), array (  '_controller' => 'Test\\TestBundle\\Controller\\DefaultController::getProductosAction',  '_format' => 'json',));
            }
            not_get_productos:

            // get_producto
            if (preg_match('#^/api/producto/(?P<id>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_get_producto;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_producto')), array (  '_controller' => 'Test\\TestBundle\\Controller\\DefaultController::getProductoAction',  '_format' => 'json',));
            }
            not_get_producto:

            // post_producto
            if (preg_match('#^/api/producto(?:\\.(?P<_format>xml|json|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_post_producto;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_producto')), array (  '_controller' => 'Test\\TestBundle\\Controller\\DefaultController::postProductoAction',  '_format' => 'json',));
            }
            not_post_producto:

            // put_producto
            if (preg_match('#^/api/producto/(?P<id>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'PUT') {
                    $allow[] = 'PUT';
                    goto not_put_producto;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'put_producto')), array (  '_controller' => 'Test\\TestBundle\\Controller\\DefaultController::putProductoAction',  '_format' => 'json',));
            }
            not_put_producto:

            // delete_producto
            if (preg_match('#^/api/producto/(?P<id>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'DELETE') {
                    $allow[] = 'DELETE';
                    goto not_delete_producto;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_producto')), array (  '_controller' => 'Test\\TestBundle\\Controller\\DefaultController::deleteProductoAction',  '_format' => 'json',));
            }
            not_delete_producto:

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
