<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_dbc7b81a49404b4f7f1ac328f9257435cb188f21be176a47b24cb0d1ceb3b94f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7066e4a0ab7b2a6cbb6951bd4d971a470391ceaa1945535d8cfd13ca59c3a0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7066e4a0ab7b2a6cbb6951bd4d971a470391ceaa1945535d8cfd13ca59c3a0a->enter($__internal_d7066e4a0ab7b2a6cbb6951bd4d971a470391ceaa1945535d8cfd13ca59c3a0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d7066e4a0ab7b2a6cbb6951bd4d971a470391ceaa1945535d8cfd13ca59c3a0a->leave($__internal_d7066e4a0ab7b2a6cbb6951bd4d971a470391ceaa1945535d8cfd13ca59c3a0a_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_fed704bd7b1c66af2a276f953a3d5662e83706eeed08795dde8e24e52b66da85 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fed704bd7b1c66af2a276f953a3d5662e83706eeed08795dde8e24e52b66da85->enter($__internal_fed704bd7b1c66af2a276f953a3d5662e83706eeed08795dde8e24e52b66da85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_fed704bd7b1c66af2a276f953a3d5662e83706eeed08795dde8e24e52b66da85->leave($__internal_fed704bd7b1c66af2a276f953a3d5662e83706eeed08795dde8e24e52b66da85_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_3537110e0ef6dd2c3c65d7d57703c6b954aa7f4d021eabccc7658c8cff1f2d10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3537110e0ef6dd2c3c65d7d57703c6b954aa7f4d021eabccc7658c8cff1f2d10->enter($__internal_3537110e0ef6dd2c3c65d7d57703c6b954aa7f4d021eabccc7658c8cff1f2d10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_3537110e0ef6dd2c3c65d7d57703c6b954aa7f4d021eabccc7658c8cff1f2d10->leave($__internal_3537110e0ef6dd2c3c65d7d57703c6b954aa7f4d021eabccc7658c8cff1f2d10_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_520c69f74208076209a3fb4bc286b7a3ad0ac2b3a98125072faa87c7384e2aaf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_520c69f74208076209a3fb4bc286b7a3ad0ac2b3a98125072faa87c7384e2aaf->enter($__internal_520c69f74208076209a3fb4bc286b7a3ad0ac2b3a98125072faa87c7384e2aaf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_520c69f74208076209a3fb4bc286b7a3ad0ac2b3a98125072faa87c7384e2aaf->leave($__internal_520c69f74208076209a3fb4bc286b7a3ad0ac2b3a98125072faa87c7384e2aaf_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
