<?php

/* ::base.html.twig */
class __TwigTemplate_462cd0500e0a29e345dc92c63e0a19bcb5ecea1d5677b5008f933c7fcffd3269 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f4998b41b8a7e11e49c99bb1c27464f2308b3346d1b253d03ecc96d86c14471 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f4998b41b8a7e11e49c99bb1c27464f2308b3346d1b253d03ecc96d86c14471->enter($__internal_0f4998b41b8a7e11e49c99bb1c27464f2308b3346d1b253d03ecc96d86c14471_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_0f4998b41b8a7e11e49c99bb1c27464f2308b3346d1b253d03ecc96d86c14471->leave($__internal_0f4998b41b8a7e11e49c99bb1c27464f2308b3346d1b253d03ecc96d86c14471_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_b8304b6d9625fce4a9c7ec3a6070cdc1bb8380923dd419d76277775b3c438fdc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8304b6d9625fce4a9c7ec3a6070cdc1bb8380923dd419d76277775b3c438fdc->enter($__internal_b8304b6d9625fce4a9c7ec3a6070cdc1bb8380923dd419d76277775b3c438fdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_b8304b6d9625fce4a9c7ec3a6070cdc1bb8380923dd419d76277775b3c438fdc->leave($__internal_b8304b6d9625fce4a9c7ec3a6070cdc1bb8380923dd419d76277775b3c438fdc_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4781a1ba6c9e83d125d51871694cff0d8f604322ed7b6b37aab9fd5699450969 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4781a1ba6c9e83d125d51871694cff0d8f604322ed7b6b37aab9fd5699450969->enter($__internal_4781a1ba6c9e83d125d51871694cff0d8f604322ed7b6b37aab9fd5699450969_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_4781a1ba6c9e83d125d51871694cff0d8f604322ed7b6b37aab9fd5699450969->leave($__internal_4781a1ba6c9e83d125d51871694cff0d8f604322ed7b6b37aab9fd5699450969_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_3fd78038cfb367da6e14a5a4d9abe186cf242f12017b73efa86cd8402193bbe1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fd78038cfb367da6e14a5a4d9abe186cf242f12017b73efa86cd8402193bbe1->enter($__internal_3fd78038cfb367da6e14a5a4d9abe186cf242f12017b73efa86cd8402193bbe1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3fd78038cfb367da6e14a5a4d9abe186cf242f12017b73efa86cd8402193bbe1->leave($__internal_3fd78038cfb367da6e14a5a4d9abe186cf242f12017b73efa86cd8402193bbe1_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_70ca965369025d0f72b50f938b1d69fc5827d3ed49ce0959ce33c96091ac8039 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70ca965369025d0f72b50f938b1d69fc5827d3ed49ce0959ce33c96091ac8039->enter($__internal_70ca965369025d0f72b50f938b1d69fc5827d3ed49ce0959ce33c96091ac8039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_70ca965369025d0f72b50f938b1d69fc5827d3ed49ce0959ce33c96091ac8039->leave($__internal_70ca965369025d0f72b50f938b1d69fc5827d3ed49ce0959ce33c96091ac8039_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\app/Resources\\views/base.html.twig");
    }
}
