<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_ef6288bbf7035d1f379dc0f84160a85bd265c7309e9a33fcfe0997ec988a62c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc81d9027a45cd89ecea1714785b9179251c437b4c3eeb529a509e5e86c7cbb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc81d9027a45cd89ecea1714785b9179251c437b4c3eeb529a509e5e86c7cbb1->enter($__internal_dc81d9027a45cd89ecea1714785b9179251c437b4c3eeb529a509e5e86c7cbb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_dc81d9027a45cd89ecea1714785b9179251c437b4c3eeb529a509e5e86c7cbb1->leave($__internal_dc81d9027a45cd89ecea1714785b9179251c437b4c3eeb529a509e5e86c7cbb1_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_e58274dad5d454db69fff3554bff2f803d6a1dbace82a52ccf1f53012fe44234 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e58274dad5d454db69fff3554bff2f803d6a1dbace82a52ccf1f53012fe44234->enter($__internal_e58274dad5d454db69fff3554bff2f803d6a1dbace82a52ccf1f53012fe44234_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_e58274dad5d454db69fff3554bff2f803d6a1dbace82a52ccf1f53012fe44234->leave($__internal_e58274dad5d454db69fff3554bff2f803d6a1dbace82a52ccf1f53012fe44234_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
