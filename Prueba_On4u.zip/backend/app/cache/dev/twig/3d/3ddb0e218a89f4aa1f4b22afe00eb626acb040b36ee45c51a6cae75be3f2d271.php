<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_50a496e71b35b57f6ff1cee3c4d1449a56f0fa1244cfca5b2379ad59a8d2ce49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1d9e71d6bd2e9c4aa46fc20fcb104d8e733c13cb45521a94ec9c4085aced107 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1d9e71d6bd2e9c4aa46fc20fcb104d8e733c13cb45521a94ec9c4085aced107->enter($__internal_f1d9e71d6bd2e9c4aa46fc20fcb104d8e733c13cb45521a94ec9c4085aced107_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_f1d9e71d6bd2e9c4aa46fc20fcb104d8e733c13cb45521a94ec9c4085aced107->leave($__internal_f1d9e71d6bd2e9c4aa46fc20fcb104d8e733c13cb45521a94ec9c4085aced107_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
