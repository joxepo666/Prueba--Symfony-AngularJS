<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_5c078db57d5d3fe5c87f73a59553992675217329e5ea4f4ed97f7daa3d88fda9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_302e76e7fc50ba1a1a248588cc6e5f4f5097a1e0f0f56f9233f077088b105897 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_302e76e7fc50ba1a1a248588cc6e5f4f5097a1e0f0f56f9233f077088b105897->enter($__internal_302e76e7fc50ba1a1a248588cc6e5f4f5097a1e0f0f56f9233f077088b105897_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_302e76e7fc50ba1a1a248588cc6e5f4f5097a1e0f0f56f9233f077088b105897->leave($__internal_302e76e7fc50ba1a1a248588cc6e5f4f5097a1e0f0f56f9233f077088b105897_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_4f212bd1307e338f4f6b062c54e4d3f3c235e4c3a7c8f698ea1671d74a05fc46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f212bd1307e338f4f6b062c54e4d3f3c235e4c3a7c8f698ea1671d74a05fc46->enter($__internal_4f212bd1307e338f4f6b062c54e4d3f3c235e4c3a7c8f698ea1671d74a05fc46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_4f212bd1307e338f4f6b062c54e4d3f3c235e4c3a7c8f698ea1671d74a05fc46->leave($__internal_4f212bd1307e338f4f6b062c54e4d3f3c235e4c3a7c8f698ea1671d74a05fc46_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
