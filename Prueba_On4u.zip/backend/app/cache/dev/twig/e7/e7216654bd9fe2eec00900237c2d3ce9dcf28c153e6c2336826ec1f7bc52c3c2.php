<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_d812dc3dce0489c501ea2b17131bac7a6d5d472cdd14ce772551b4241b3b43b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a737bccd8dfce191aa71cfaf5a424e37ff551aed8ec1ba5c562e88b74aa10f08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a737bccd8dfce191aa71cfaf5a424e37ff551aed8ec1ba5c562e88b74aa10f08->enter($__internal_a737bccd8dfce191aa71cfaf5a424e37ff551aed8ec1ba5c562e88b74aa10f08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_a737bccd8dfce191aa71cfaf5a424e37ff551aed8ec1ba5c562e88b74aa10f08->leave($__internal_a737bccd8dfce191aa71cfaf5a424e37ff551aed8ec1ba5c562e88b74aa10f08_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
