<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_45cd2744ce0b9c8af11c905b21af3be402c18dd18f92c2003c867163ee679e2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1d3d3fee27efb3e4d940a7879406e4a50fdb211ff4d041e2935226b055f35c42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d3d3fee27efb3e4d940a7879406e4a50fdb211ff4d041e2935226b055f35c42->enter($__internal_1d3d3fee27efb3e4d940a7879406e4a50fdb211ff4d041e2935226b055f35c42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        
        $__internal_1d3d3fee27efb3e4d940a7879406e4a50fdb211ff4d041e2935226b055f35c42->leave($__internal_1d3d3fee27efb3e4d940a7879406e4a50fdb211ff4d041e2935226b055f35c42_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "@Twig/Exception/exception.atom.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
