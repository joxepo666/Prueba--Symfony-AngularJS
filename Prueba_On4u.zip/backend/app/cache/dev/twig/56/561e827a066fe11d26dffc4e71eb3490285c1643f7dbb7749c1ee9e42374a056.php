<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_2591b65a29821084166bd8d93a0d81e59d620343fa74ffeab8a46f4c630351b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4a9d5e24187d4ff96abd03461ae96fa8b0e850578ea5dfead4bc4012c3a1ce6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4a9d5e24187d4ff96abd03461ae96fa8b0e850578ea5dfead4bc4012c3a1ce6->enter($__internal_b4a9d5e24187d4ff96abd03461ae96fa8b0e850578ea5dfead4bc4012c3a1ce6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4a9d5e24187d4ff96abd03461ae96fa8b0e850578ea5dfead4bc4012c3a1ce6->leave($__internal_b4a9d5e24187d4ff96abd03461ae96fa8b0e850578ea5dfead4bc4012c3a1ce6_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_194265398ae170159e895d417a99f0fd398f75856ae203602961e40f7f3dfbfd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_194265398ae170159e895d417a99f0fd398f75856ae203602961e40f7f3dfbfd->enter($__internal_194265398ae170159e895d417a99f0fd398f75856ae203602961e40f7f3dfbfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_194265398ae170159e895d417a99f0fd398f75856ae203602961e40f7f3dfbfd->leave($__internal_194265398ae170159e895d417a99f0fd398f75856ae203602961e40f7f3dfbfd_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_3011cf8f219cd0fe2507c7fc7d5740564b0220349be19aeaf068e57c1cdbdb2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3011cf8f219cd0fe2507c7fc7d5740564b0220349be19aeaf068e57c1cdbdb2b->enter($__internal_3011cf8f219cd0fe2507c7fc7d5740564b0220349be19aeaf068e57c1cdbdb2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_3011cf8f219cd0fe2507c7fc7d5740564b0220349be19aeaf068e57c1cdbdb2b->leave($__internal_3011cf8f219cd0fe2507c7fc7d5740564b0220349be19aeaf068e57c1cdbdb2b_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_e8320b8cfcf0beea6e012a2227d1bf44589aa040251368464b6ad8e8c30376b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8320b8cfcf0beea6e012a2227d1bf44589aa040251368464b6ad8e8c30376b3->enter($__internal_e8320b8cfcf0beea6e012a2227d1bf44589aa040251368464b6ad8e8c30376b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_e8320b8cfcf0beea6e012a2227d1bf44589aa040251368464b6ad8e8c30376b3->leave($__internal_e8320b8cfcf0beea6e012a2227d1bf44589aa040251368464b6ad8e8c30376b3_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "TwigBundle:Exception:exception_full.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
