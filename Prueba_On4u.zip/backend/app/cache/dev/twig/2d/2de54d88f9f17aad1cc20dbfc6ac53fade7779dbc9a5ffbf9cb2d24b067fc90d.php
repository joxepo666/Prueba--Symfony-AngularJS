<?php

/* @SensioDistribution/Configurator/layout.html.twig */
class __TwigTemplate_cc7ed8b37436583b267ad22cdb783be5452f8424c946ca510e0626f4190e8eaf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "@SensioDistribution/Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1204359691f5489e4236f913316be24158dcf19f7a9f029de4d23d6f6d5b53a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1204359691f5489e4236f913316be24158dcf19f7a9f029de4d23d6f6d5b53a->enter($__internal_f1204359691f5489e4236f913316be24158dcf19f7a9f029de4d23d6f6d5b53a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SensioDistribution/Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f1204359691f5489e4236f913316be24158dcf19f7a9f029de4d23d6f6d5b53a->leave($__internal_f1204359691f5489e4236f913316be24158dcf19f7a9f029de4d23d6f6d5b53a_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_cff91ce02bfd9f75140f88fcb752f98a2f9410fad819895266a3ae4d26da6733 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cff91ce02bfd9f75140f88fcb752f98a2f9410fad819895266a3ae4d26da6733->enter($__internal_cff91ce02bfd9f75140f88fcb752f98a2f9410fad819895266a3ae4d26da6733_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_cff91ce02bfd9f75140f88fcb752f98a2f9410fad819895266a3ae4d26da6733->leave($__internal_cff91ce02bfd9f75140f88fcb752f98a2f9410fad819895266a3ae4d26da6733_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_4498afc1d7720b9cc1513be0b029cf92063bd25f516ceb901dbff44010190f47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4498afc1d7720b9cc1513be0b029cf92063bd25f516ceb901dbff44010190f47->enter($__internal_4498afc1d7720b9cc1513be0b029cf92063bd25f516ceb901dbff44010190f47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_4498afc1d7720b9cc1513be0b029cf92063bd25f516ceb901dbff44010190f47->leave($__internal_4498afc1d7720b9cc1513be0b029cf92063bd25f516ceb901dbff44010190f47_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_3b191175ed51280a2f4bb09d4215c2d79eadf0ccf92362eba71cd6d54b2e9c03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b191175ed51280a2f4bb09d4215c2d79eadf0ccf92362eba71cd6d54b2e9c03->enter($__internal_3b191175ed51280a2f4bb09d4215c2d79eadf0ccf92362eba71cd6d54b2e9c03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, ($context["version"] ?? $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_3b191175ed51280a2f4bb09d4215c2d79eadf0ccf92362eba71cd6d54b2e9c03->leave($__internal_3b191175ed51280a2f4bb09d4215c2d79eadf0ccf92362eba71cd6d54b2e9c03_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_0d4d5dc2ef438372165513d54cf9231c037bcb037cb9ff29c178081dd55e9baf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d4d5dc2ef438372165513d54cf9231c037bcb037cb9ff29c178081dd55e9baf->enter($__internal_0d4d5dc2ef438372165513d54cf9231c037bcb037cb9ff29c178081dd55e9baf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_0d4d5dc2ef438372165513d54cf9231c037bcb037cb9ff29c178081dd55e9baf->leave($__internal_0d4d5dc2ef438372165513d54cf9231c037bcb037cb9ff29c178081dd55e9baf_prof);

    }

    public function getTemplateName()
    {
        return "@SensioDistribution/Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"TwigBundle::layout.html.twig\" %}

{% block head %}
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}\" />
{% endblock %}

{% block title 'Web Configurator Bundle' %}

{% block body %}
    <div class=\"block\">
        {% block content %}{% endblock %}
    </div>
    <div class=\"version\">Symfony Standard Edition v.{{ version }}</div>
{% endblock %}
", "@SensioDistribution/Configurator/layout.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\sensio\\distribution-bundle\\Sensio\\Bundle\\DistributionBundle\\Resources\\views\\Configurator\\layout.html.twig");
    }
}
