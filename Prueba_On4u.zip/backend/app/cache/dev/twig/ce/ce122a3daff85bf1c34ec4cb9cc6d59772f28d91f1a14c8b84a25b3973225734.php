<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_90c9f63ccbdc06d6736477e78629267d74a64574ee54b8cc7c747b2f5b309c53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba769d981ea96ce2a00c37ae67be1302404982369b132c2e49a135ae82d12592 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba769d981ea96ce2a00c37ae67be1302404982369b132c2e49a135ae82d12592->enter($__internal_ba769d981ea96ce2a00c37ae67be1302404982369b132c2e49a135ae82d12592_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ba769d981ea96ce2a00c37ae67be1302404982369b132c2e49a135ae82d12592->leave($__internal_ba769d981ea96ce2a00c37ae67be1302404982369b132c2e49a135ae82d12592_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_92a9b3f565f537597a82faaf7996bb3e914cb7d1966c44ab13140fb754c8f7e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92a9b3f565f537597a82faaf7996bb3e914cb7d1966c44ab13140fb754c8f7e8->enter($__internal_92a9b3f565f537597a82faaf7996bb3e914cb7d1966c44ab13140fb754c8f7e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_92a9b3f565f537597a82faaf7996bb3e914cb7d1966c44ab13140fb754c8f7e8->leave($__internal_92a9b3f565f537597a82faaf7996bb3e914cb7d1966c44ab13140fb754c8f7e8_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_13bd7f03a1c1dee4b1cd4943dcc0a7a80105e4680d8d9eacfd37ab1a438a109c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13bd7f03a1c1dee4b1cd4943dcc0a7a80105e4680d8d9eacfd37ab1a438a109c->enter($__internal_13bd7f03a1c1dee4b1cd4943dcc0a7a80105e4680d8d9eacfd37ab1a438a109c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_13bd7f03a1c1dee4b1cd4943dcc0a7a80105e4680d8d9eacfd37ab1a438a109c->leave($__internal_13bd7f03a1c1dee4b1cd4943dcc0a7a80105e4680d8d9eacfd37ab1a438a109c_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_1be204e977c5d6d4ea5cd3acd4974e0a2b4f0ec1c3d03cc2e3e71efb5b898f2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1be204e977c5d6d4ea5cd3acd4974e0a2b4f0ec1c3d03cc2e3e71efb5b898f2b->enter($__internal_1be204e977c5d6d4ea5cd3acd4974e0a2b4f0ec1c3d03cc2e3e71efb5b898f2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_1be204e977c5d6d4ea5cd3acd4974e0a2b4f0ec1c3d03cc2e3e71efb5b898f2b->leave($__internal_1be204e977c5d6d4ea5cd3acd4974e0a2b4f0ec1c3d03cc2e3e71efb5b898f2b_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
