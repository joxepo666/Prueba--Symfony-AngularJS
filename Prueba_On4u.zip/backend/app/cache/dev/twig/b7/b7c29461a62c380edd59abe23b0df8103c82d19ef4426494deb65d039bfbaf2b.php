<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_b442059caf2f58dc41cd3153af66839832271e57cd89da0c49418d1f3ec5981e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6691b35c632c962705ecff4aabe28b218022b88b0c1750b4c7d2dfb33d63d43f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6691b35c632c962705ecff4aabe28b218022b88b0c1750b4c7d2dfb33d63d43f->enter($__internal_6691b35c632c962705ecff4aabe28b218022b88b0c1750b4c7d2dfb33d63d43f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_6691b35c632c962705ecff4aabe28b218022b88b0c1750b4c7d2dfb33d63d43f->leave($__internal_6691b35c632c962705ecff4aabe28b218022b88b0c1750b4c7d2dfb33d63d43f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.atom.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
