<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_99782603342f9eddd436553d89d93ed7e24bfeb1892239b03f1127feaf7425e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a8b6f1de4336d314f06550d6cf5a2d9cf8dfc069d16299b9bc68e65efdaba8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a8b6f1de4336d314f06550d6cf5a2d9cf8dfc069d16299b9bc68e65efdaba8c->enter($__internal_7a8b6f1de4336d314f06550d6cf5a2d9cf8dfc069d16299b9bc68e65efdaba8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_7a8b6f1de4336d314f06550d6cf5a2d9cf8dfc069d16299b9bc68e65efdaba8c->leave($__internal_7a8b6f1de4336d314f06550d6cf5a2d9cf8dfc069d16299b9bc68e65efdaba8c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
