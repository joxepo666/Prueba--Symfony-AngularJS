<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_e2e7a34376b3c18951c4246c4e25d05e81892487ecdf0c8034e396e2a775b868 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aaa8a8db13ed830a7c8051fdeb6c943ad08c27fdbde039c631fe0c37016598d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aaa8a8db13ed830a7c8051fdeb6c943ad08c27fdbde039c631fe0c37016598d3->enter($__internal_aaa8a8db13ed830a7c8051fdeb6c943ad08c27fdbde039c631fe0c37016598d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aaa8a8db13ed830a7c8051fdeb6c943ad08c27fdbde039c631fe0c37016598d3->leave($__internal_aaa8a8db13ed830a7c8051fdeb6c943ad08c27fdbde039c631fe0c37016598d3_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_c0cd5bab5ea09b99aed88e8346c4121e2e5c2b8eb32bcab01666a232083d5300 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0cd5bab5ea09b99aed88e8346c4121e2e5c2b8eb32bcab01666a232083d5300->enter($__internal_c0cd5bab5ea09b99aed88e8346c4121e2e5c2b8eb32bcab01666a232083d5300_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_c0cd5bab5ea09b99aed88e8346c4121e2e5c2b8eb32bcab01666a232083d5300->leave($__internal_c0cd5bab5ea09b99aed88e8346c4121e2e5c2b8eb32bcab01666a232083d5300_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_4226ab2e22226a8a6c9d41673583743f81f07e57e786aaf9e2e539ac3ab7531d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4226ab2e22226a8a6c9d41673583743f81f07e57e786aaf9e2e539ac3ab7531d->enter($__internal_4226ab2e22226a8a6c9d41673583743f81f07e57e786aaf9e2e539ac3ab7531d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_4226ab2e22226a8a6c9d41673583743f81f07e57e786aaf9e2e539ac3ab7531d->leave($__internal_4226ab2e22226a8a6c9d41673583743f81f07e57e786aaf9e2e539ac3ab7531d_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_f0c54d3faaff1e31fdbc0143b2b10f587b21639bd275d0ba93a0979e28bd3013 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0c54d3faaff1e31fdbc0143b2b10f587b21639bd275d0ba93a0979e28bd3013->enter($__internal_f0c54d3faaff1e31fdbc0143b2b10f587b21639bd275d0ba93a0979e28bd3013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, ($context["version"] ?? $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_f0c54d3faaff1e31fdbc0143b2b10f587b21639bd275d0ba93a0979e28bd3013->leave($__internal_f0c54d3faaff1e31fdbc0143b2b10f587b21639bd275d0ba93a0979e28bd3013_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_c7df6a4077f7f86d63d7994d6dd25f9d58bcad656247e8c90b21c03f6e012b13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7df6a4077f7f86d63d7994d6dd25f9d58bcad656247e8c90b21c03f6e012b13->enter($__internal_c7df6a4077f7f86d63d7994d6dd25f9d58bcad656247e8c90b21c03f6e012b13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_c7df6a4077f7f86d63d7994d6dd25f9d58bcad656247e8c90b21c03f6e012b13->leave($__internal_c7df6a4077f7f86d63d7994d6dd25f9d58bcad656247e8c90b21c03f6e012b13_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"TwigBundle::layout.html.twig\" %}

{% block head %}
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}\" />
{% endblock %}

{% block title 'Web Configurator Bundle' %}

{% block body %}
    <div class=\"block\">
        {% block content %}{% endblock %}
    </div>
    <div class=\"version\">Symfony Standard Edition v.{{ version }}</div>
{% endblock %}
", "SensioDistributionBundle::Configurator/layout.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\sensio\\distribution-bundle\\Sensio\\Bundle\\DistributionBundle/Resources/views/Configurator/layout.html.twig");
    }
}
