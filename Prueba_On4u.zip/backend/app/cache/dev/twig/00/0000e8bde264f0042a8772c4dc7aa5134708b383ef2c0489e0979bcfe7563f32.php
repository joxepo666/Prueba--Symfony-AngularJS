<?php

/* base.html.twig */
class __TwigTemplate_45a3e83a3f7ca3837facd5bc6d8226e9b064edc1ced728f52134c49f90b66023 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b1cdbe4399b696dde29cd0a3702edc83d0080ce95ce25485a6786b930c6a4118 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1cdbe4399b696dde29cd0a3702edc83d0080ce95ce25485a6786b930c6a4118->enter($__internal_b1cdbe4399b696dde29cd0a3702edc83d0080ce95ce25485a6786b930c6a4118_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_b1cdbe4399b696dde29cd0a3702edc83d0080ce95ce25485a6786b930c6a4118->leave($__internal_b1cdbe4399b696dde29cd0a3702edc83d0080ce95ce25485a6786b930c6a4118_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_3ded41ac8be07b1d834a9bb1a3100c1c5f6f76d7dee80b975199a524c2482dd2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ded41ac8be07b1d834a9bb1a3100c1c5f6f76d7dee80b975199a524c2482dd2->enter($__internal_3ded41ac8be07b1d834a9bb1a3100c1c5f6f76d7dee80b975199a524c2482dd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_3ded41ac8be07b1d834a9bb1a3100c1c5f6f76d7dee80b975199a524c2482dd2->leave($__internal_3ded41ac8be07b1d834a9bb1a3100c1c5f6f76d7dee80b975199a524c2482dd2_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a8935555d7307f3c53ba6b92b68f16cd83878f3c6cc1ab707e3947535b2f933b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8935555d7307f3c53ba6b92b68f16cd83878f3c6cc1ab707e3947535b2f933b->enter($__internal_a8935555d7307f3c53ba6b92b68f16cd83878f3c6cc1ab707e3947535b2f933b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_a8935555d7307f3c53ba6b92b68f16cd83878f3c6cc1ab707e3947535b2f933b->leave($__internal_a8935555d7307f3c53ba6b92b68f16cd83878f3c6cc1ab707e3947535b2f933b_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_33c908c71cd07d343fca7bc297b90b0ef17f77ff11f0b7f6b6b9f2d1682519be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33c908c71cd07d343fca7bc297b90b0ef17f77ff11f0b7f6b6b9f2d1682519be->enter($__internal_33c908c71cd07d343fca7bc297b90b0ef17f77ff11f0b7f6b6b9f2d1682519be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_33c908c71cd07d343fca7bc297b90b0ef17f77ff11f0b7f6b6b9f2d1682519be->leave($__internal_33c908c71cd07d343fca7bc297b90b0ef17f77ff11f0b7f6b6b9f2d1682519be_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c429adf8173378027975a7209674af0fc61f07048cbaab1ba5d2d1b9edcfd6a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c429adf8173378027975a7209674af0fc61f07048cbaab1ba5d2d1b9edcfd6a1->enter($__internal_c429adf8173378027975a7209674af0fc61f07048cbaab1ba5d2d1b9edcfd6a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_c429adf8173378027975a7209674af0fc61f07048cbaab1ba5d2d1b9edcfd6a1->leave($__internal_c429adf8173378027975a7209674af0fc61f07048cbaab1ba5d2d1b9edcfd6a1_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\app\\Resources\\views\\base.html.twig");
    }
}
