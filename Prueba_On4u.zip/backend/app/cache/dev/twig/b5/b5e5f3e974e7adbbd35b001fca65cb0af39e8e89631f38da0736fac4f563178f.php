<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_68250d8adb1c360aabedeef6f651ea4bd136ea5d84a65de1e9fa8e33057a1275 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a8231926172b7f91f6c5a01433c275724c4302cb9e38843c188e0b60d2f39a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a8231926172b7f91f6c5a01433c275724c4302cb9e38843c188e0b60d2f39a7->enter($__internal_7a8231926172b7f91f6c5a01433c275724c4302cb9e38843c188e0b60d2f39a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_7a8231926172b7f91f6c5a01433c275724c4302cb9e38843c188e0b60d2f39a7->leave($__internal_7a8231926172b7f91f6c5a01433c275724c4302cb9e38843c188e0b60d2f39a7_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
