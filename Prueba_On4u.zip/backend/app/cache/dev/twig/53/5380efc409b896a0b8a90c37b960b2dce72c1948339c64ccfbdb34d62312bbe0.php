<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_820e1a29ac5358898e962ea33c3150b33a6ad4f1d2932500735ae036fbd8c962 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b40328880a1b8c4645b7502d8e2fb1e63ca831e781bcfad657b08f24f2bc55d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b40328880a1b8c4645b7502d8e2fb1e63ca831e781bcfad657b08f24f2bc55d2->enter($__internal_b40328880a1b8c4645b7502d8e2fb1e63ca831e781bcfad657b08f24f2bc55d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_b40328880a1b8c4645b7502d8e2fb1e63ca831e781bcfad657b08f24f2bc55d2->leave($__internal_b40328880a1b8c4645b7502d8e2fb1e63ca831e781bcfad657b08f24f2bc55d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\Users\\Administrador\\Documents\\Prueba on4u\\test_1\\backend\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
